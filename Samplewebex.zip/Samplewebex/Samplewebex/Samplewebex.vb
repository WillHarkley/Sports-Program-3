﻿Public Class frmSportsBudget
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        'Declare Variables
        Dim intplayer As Integer
        Dim intsportcost As Integer
        Dim inttotalcost As Integer
        Dim strsport As String

        'intplayer = txtPot.Text

        If txtPot.Text = "" Then
            MessageBox.Show("Please enter the number of players")
            txtPot.Focus()
        End If


        If cboSports.SelectedIndex = -1 Then
            MessageBox.Show("Please select a sport")
        Else
            strsport = cboSports.SelectedItem
        End If

        'Set Variable

        Integer.TryParse(txtPot.Text, intplayer)


#Disable Warning BC42104 ' Variable is used before it has been assigned a value
        intsportcost = getSportCost(strsport)
#Enable Warning BC42104 ' Variable is used before it has been assigned a value

        'Calculation

        'total cost = cost of the sport * number of players

        inttotalcost = intsportcost * intplayer

        costDisplay(inttotalcost)

        lstDisplay.Items.Add("The sport you chose is " & strsport)
        lstDisplay.Items.Add("The sport cost " & intsportcost)
        lstDisplay.Items.Add("You total cost for this sport is " & FormatCurrency(inttotalcost))

    End Sub

    Private Sub costDisplay(ByVal inttotalcost As Integer)
        'Display
        If inttotalcost > 5000 Then
            MessageBox.Show("You are spending way too much")
        Else
            MessageBox.Show("Your are cheap")
        End If
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        cboSports.SelectedIndex = -1
        lstDisplay.Items.Clear()
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Function getSportCost(ByVal strsport As String) As Integer
        Dim intsportcost As Integer
#Disable Warning BC42104 ' Variable is used before it has been assigned a value
        Select Case strsport
#Enable Warning BC42104 ' Variable is used before it has been assigned a value
            Case "Football"
                intsportcost = 350

            Case "Soccer"
                intsportcost = 200

            Case "Basketball"
                intsportcost = 400
            Case Else
                MessageBox.Show("Please enter sports value")

        End Select
        Return intsportcost
    End Function
End Class
