﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSportsBudget
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.txtPot = New System.Windows.Forms.TextBox()
        Me.lblNumberofplayers = New System.Windows.Forms.Label()
        Me.cboSports = New System.Windows.Forms.ComboBox()
        Me.lblSports = New System.Windows.Forms.Label()
        Me.lstDisplay = New System.Windows.Forms.ListBox()
        Me.SuspendLayout()
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(575, 311)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(123, 59)
        Me.btnClose.TabIndex = 14
        Me.btnClose.Text = "&Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(368, 309)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(123, 59)
        Me.btnClear.TabIndex = 12
        Me.btnClear.Text = "&Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(145, 309)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(139, 61)
        Me.btnCalculate.TabIndex = 11
        Me.btnCalculate.Text = "&Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'txtPot
        '
        Me.txtPot.Location = New System.Drawing.Point(466, 148)
        Me.txtPot.Name = "txtPot"
        Me.txtPot.Size = New System.Drawing.Size(135, 20)
        Me.txtPot.TabIndex = 10
        '
        'lblNumberofplayers
        '
        Me.lblNumberofplayers.AutoSize = True
        Me.lblNumberofplayers.Location = New System.Drawing.Point(462, 118)
        Me.lblNumberofplayers.Name = "lblNumberofplayers"
        Me.lblNumberofplayers.Size = New System.Drawing.Size(93, 13)
        Me.lblNumberofplayers.TabIndex = 9
        Me.lblNumberofplayers.Text = "Number of Players"
        '
        'cboSports
        '
        Me.cboSports.FormattingEnabled = True
        Me.cboSports.Items.AddRange(New Object() {"Football", "Soccer", "Basketball"})
        Me.cboSports.Location = New System.Drawing.Point(145, 148)
        Me.cboSports.Name = "cboSports"
        Me.cboSports.Size = New System.Drawing.Size(139, 21)
        Me.cboSports.TabIndex = 15
        '
        'lblSports
        '
        Me.lblSports.AutoSize = True
        Me.lblSports.Location = New System.Drawing.Point(142, 118)
        Me.lblSports.Name = "lblSports"
        Me.lblSports.Size = New System.Drawing.Size(37, 13)
        Me.lblSports.TabIndex = 16
        Me.lblSports.Text = "Sports"
        '
        'lstDisplay
        '
        Me.lstDisplay.FormattingEnabled = True
        Me.lstDisplay.Location = New System.Drawing.Point(218, 189)
        Me.lstDisplay.Name = "lstDisplay"
        Me.lstDisplay.Size = New System.Drawing.Size(337, 95)
        Me.lstDisplay.TabIndex = 17
        '
        'frmSportsBudget
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.lstDisplay)
        Me.Controls.Add(Me.lblSports)
        Me.Controls.Add(Me.cboSports)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.txtPot)
        Me.Controls.Add(Me.lblNumberofplayers)
        Me.Name = "frmSportsBudget"
        Me.Text = "Sports Budget"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnClose As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnCalculate As Button
    Friend WithEvents txtPot As TextBox
    Friend WithEvents lblNumberofplayers As Label
    Friend WithEvents cboSports As ComboBox
    Friend WithEvents lblSports As Label
    Friend WithEvents lstDisplay As ListBox
End Class
